#!/bin/bash

data_dir="true_nanolen_tease25";
N="10000";

# this one from simulated cross

crosses_sim="../sim_data/simulation_data_match_N"${N}"_"${data_dir}"/input_profile_mean_chr3_2way.txt.N1.0e5.6330.sample.1.Ns"${N}".12gen";

wc $crosses_sim

index_id=0;
while read seed
do
let index_id++
perl ./bootstrap.pl -i $crosses_sim -o $crosses_sim".resample."$index_id".int.fa" -s $seed

done < seed.vector.500.txt





