/*
$./gen_third_locs <input_loc>
*/
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <vector>
#include <math.h>

using namespace std;

int main(int argc, char ** argv){
	string common_title=argv[1];
	string out_1=common_title+".third.1";
	string out_2=common_title+".third.2";
	string out_3=common_title+".third.3";
	
	remove(out_1.c_str());
	remove(out_3.c_str());
	remove(out_2.c_str());
	ofstream outfile_1(out_1, ios::app);
	ofstream outfile_2(out_2, ios::app);
	ofstream outfile_3(out_3, ios::app);

	ifstream infile(common_title);
	int n=1431/3;
	int count=0;
	string line;
	while (getline(infile, line)){
		count++;
		if(count==2){
			stringstream line_ss;
			line_ss<<line;
			double d;
			int d_count=0;
			vector <double> v_1, v_2, v_3;
			while(line_ss>>d){
				d_count++;
				if(d_count<n+1){
					v_1.push_back(d);
				}
				else if(d_count<2*n+1){
					v_2.push_back(d);
				}
				else{
					v_3.push_back(d);				
				}
			}
			outfile_1<<v_1.size()<<' '<<v_1.back()-v_1.front()<<" L\n";
			outfile_2<<v_2.size()<<' '<<v_2.back()-v_2.front()<<" L\n";
			outfile_3<<v_3.size()<<' '<<v_3.back()-v_3.front()<<" L\n";
			for(int i=0; i<n; i++){
				outfile_1<<v_1[i]<<' ';
				outfile_2<<v_2[i]<<' ';
				outfile_3<<v_3[i]<<' '; 
			}
		}	
	}
}
