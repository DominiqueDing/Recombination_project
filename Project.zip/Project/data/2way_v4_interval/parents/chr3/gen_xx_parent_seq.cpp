/*
$./gen_xx_parent_seq <fraction> <input_parents_seq_file>
*/
#include <iostream>
#include <fstream>
#include <string>
#include <stdio.h>
#include <stdlib.h>

using namespace std;

int main(int argc, char ** argv){
	int n=1431/atoi(argv[1]);
	string in_title=argv[2];
	string frac=argv[1];
	string out_title=frac+".fraction."+in_title;
	remove(out_title.c_str());
	
	ifstream infile(in_title);
	ofstream outfile(out_title);
	string line;
	int count=0;
	string p_1, p_2, seq_1, seq_2;
	while(getline(infile, line)){
		count++;
		if(count==2){
			p_1=line;
		}
		else if(count==4){
			p_2=line;		
		}
		else if(count==3){
			seq_1.assign(line.begin(), line.begin()+n);
		}
		else if(count==5){
			seq_2.assign(line.begin(), line.begin()+n);		
		}
	}
	outfile<<"2 "<<n<<" 1\n";
	outfile<<p_1<<'\n'<<seq_1<<'\n'<<p_2<<'\n'<<seq_2;
	
}
