#!/bin/bash
declare -i i

for i in ###
do
cp example-inference-sim-2way.0.0.sh example-inference-sim-2way.0.${i}.sh
done
