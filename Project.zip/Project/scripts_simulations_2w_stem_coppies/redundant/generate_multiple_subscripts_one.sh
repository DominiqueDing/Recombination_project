#!/bin/bash
declare -i i
for i in ###
do
sed "s/example-inference-sim-2way.0.0.sh/example-inference-sim-2way.0.${i}.sh/" <slurm_submit.0.0.darwin >slurm_submit.0.${i}.darwin
chmod a+x slurm_submit.0.${i}.darwin
done
