#!/bin/bash

# An example script on how to do inference as was done in the manuscript. 
# Please note that to make this example run quickly the number of steps in interval_cpp is small and the number of different runs i.e. 
# seedList has only two values and only a single bootstrap is done. While already these small numbers seem to work for (short) 
# chr1 they should be increased as necessary to get consistent results.
# This file is hopefully easy to modify for any particular system.
# Background penalty for LDhat was chosen as 25, going to 12.5 left our analyses substantially unchanged. We used 25 throughout for simulated 
# systems as well.


chrList="chr3";
replicateList="All";
#declare -i index_id_start
#declare -i index_id_end
declare -i index_id_in_title
index_id="`echo ${0//[^0-9]/ } | awk '{ print $NF }'`";
#index_id_start=${index_id_in_title}*5-4;
#index_id_end=${index_id_start}+4;
tag2="sim";
lk_fileList="../LKsurfaces/lkInfiniteNwayNg1720_realtime_g2001";
exec_dir="../codes/LDhat-modifiedStats"
exec_dir_cpp="../codes/LDhat-modifiedIntegrated"

datadir="../data/2way_v4_interval";
tmpdir="../inference_results_sim_example/inference_results_tmp";

mkdir -p $tmpdir

for chr in $chrList
do

datadir1=$datadir/"parents/"$chr;


echo $chr

i=0;
for replicate in $replicateList
do
list=($lk_fileList)
lk_file=${list[$i]}
let i++;

echo $lk_file

# these two taken from real data
loci=$datadir1/$chr.seg.loc;
parents=$datadir1/parents.$chr.int.fa;

outdir="../inference_results_sim_example"/$chr/;
outdirLK="../inference_results_sim_example"/$chr/lk/;

mkdir -p $outdir; 
mkdir -p $outdirLK;

# this one from simulated cross

crosses_sim="../sim_data/simulation_data_match/input_profile_mean_chr3_2way.txt.N1.0e5.6330.sample.1.Ns1720.12gen";

wc $crosses_sim

#seed=`head -$index_id seed.vector.500.txt | tail -1 | awk '{ print $1 }'`
#index_id=${index_id_start};
head -"${index_id}" seed.vector.500.txt | tail -1 | while read seed
do
#let index_id++
perl ../scripts_inference/bootstrap.pl -i $crosses_sim -o $crosses_sim.resample.$index_id".int.fa" -s $seed

seqFiles=$crosses_sim.resample.$index_id".int.fa"	


for seqs in $seqFiles
do
list=($(echo $seqs | tr "/" "\n"));
tag=${list[3]};

#echo $tag
#wc $seqs
#wc $loci
#wc $parents
#wc $lk_file

#seed=1234;
#seedList="1234 2334";
si=0;

#for seed2 in $seedList
while read seed2
do
let si++
#echo $si

./$exec_dir_cpp/interval_cpp -lk $lk_file -seq $seqs -loc $loci -init $parents -exact 1 -its 500000 -samp 5000 -seed $seed2 -bpen 25.0 -concise 1 -tag $tmpdir/2way.sim.$index_id. -fractions parents.2way.txt -crosses 12
cp $tmpdir/2way.sim.$index_id._lk.txt $outdirLK/lk_cpp.txt.$tag.$tag2.si.$si
./$exec_dir/stat -input $tmpdir/2way.sim.$index_id._rates.txt -loc $loci -burn 50 -tag $outdir/res_cpp.txt.$tag.$tag2.si.$si

done < Random_ints_10.in

# choose only the best optimization 
si=0;

#rm $tmpdir/2way.sim.$index_id.runs

#for seed2 in $seedList
while read seed2
do

let si++

awk 'END{printf("%s ",ARGV[1])}' $outdir/res_cpp.txt.$tag.$tag2.si.$si >> $tmpdir/2way.sim.$index_id.runs 
awk 'END{print $5,$NF }'  $outdirLK/lk_cpp.txt.$tag.$tag2.si.$si >> $tmpdir/2way.sim.$index_id.runs 

done < Random_ints_10.in

sort -n -k 2 $tmpdir/2way.sim.$index_id.runs > $tmpdir/2way.sim.$index_id.runs.sort
bestFile=`tail -1 $tmpdir/2way.sim.$index_id.runs.sort | awk '{ print $1 }'`
cp $bestFile $outdir/res_cpp.txt.$tag.$tag2.best

rm $outdirLK/lk_cpp.txt.$tag.$tag2.si.* 
rm $outdir/res_cpp.txt.$tag.$tag2.si.* 

done

done

done

done





