#!/bin/bash

./generate_multiple_scripts_one.sh
./generate_multiple_subscripts_one.sh

#make logfile
#echo "-------------------------------------------------------------" >>../submitting_job.log
#echo "-------------------------------------------------------------" >>../submitting_job.log
#date >> ../submitting_job.log
#echo `pwd` >>../submitting_job.log
#submitting jobs
declare -i i
for i in ###
do
sbatch slurm_submit.0.${i}.darwin
done
#make logfile
#squeue -u sd768 >> ../submitting_job.log


