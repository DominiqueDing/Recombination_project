#!/bin/bash

set -e
#test if customisation has already performed
if test -e customise.log; then
	echo "It has already been run, check the files!"
	exit 1
fi

#if not create logfile to mark it
echo "----------------------------------------------------------------" >>customise.log
echo "----------------------------------------------------------------" >>customise.log
date>>customise.log
echo "Running customise.sh" >> customise.log
#customise
PRECUSTOM=`pwd | awk -F '/' '{print $NF}'`
CUSTOM=`echo ${PRECUSTOM} | sed 's/scripts_simulations_2w_//'`
seq_count=`head -1 ../sim_data/simulation_data_match_N100/input_profile_mean_chr3_2way.txt.N1.0e5.6330.sample.1.Ns100.12gen | awk '{ print $1 }'`


sed -i '' "s/lkInfiniteNwayNg1720_realtime_g2001/lkInfiniteNwayNg${seq_count}_realtime_g10001/" example-inference-sim-2way.0.sh

sed -i '' "s/simulation_data_match/simulation_data_match_${CUSTOM}/" example-inference-sim-2way.0.sh

sed -i '' "s/inference_results_sim_example/inference_results_sim_example_${CUSTOM}/" example-inference-sim-2way.0.sh

#sed -i  -e "s/simulation_data_match/simulation_data_match_${CUSTOM}/" -e "s/inference_results_sim_example/inference_results_sim_example_${CUSTOM}/" example-inference-sim-2way.0.0.sh

#sed -i -e "s/scripts_simulations_2w/${PRECUSTOM}/" slurm_submit.0.darwin

#sed -i -e "s/scripts_simulations_2w/${PRECUSTOM}/" slurm_submit.0.0.darwin
