//Program to create inital pool of variants in a crossing experiment


#include <iostream>
#include <sstream>
#include <vector>
#include <list>
#include <deque>

using namespace std;
#include "crossing-tools.h"



int main(int argc, char *argv[]){
	
	
	if(argc != 7){
		cout<< "Usage ./run_crossing N Ngen Nsample seed output_dir rhoFile" <<endl;
		exit(0);
	}
	
	int N=(int)atof(argv[1]);/* how large population */
	int Ngen=atoi(argv[2]);/* number of generations of crossing */
	int Nsample=atoi(argv[3]);/* number of haplotypes sampled from the final pool */
	int seed=atoi(argv[4]); /* seed for random number generator */
	string outdir(argv[5]); /* output directory for saving the used recombination profile */
	string rhoIn(argv[6]); /* input file of recombination profile */
	
	gsl_rng_env_setup();
	srand((unsigned int)(seed)); 
	
	gsl_rng *rgen = gsl_rng_alloc (gsl_rng_taus);
	gsl_rng_set (rgen, seed);
	
	vector < std::string > population;
	vector < std::string  > populationNew;

	vector <double> nlRhoV;
	
	/* read in locus info and recombination landscape */
	read_rho(rhoIn, nlRhoV);
	
	int n_loci=nlRhoV.size()+1;

	init_population(population,N,n_loci);
	populationNew=population;
	

	for(int i=0; i< nlRhoV.size(); i++){
		nlRhoV[i]=nlRhoV[i]*(double)N;
	}
			
				
	for(int iC=0; iC< Ngen; iC++){
		combined_resample_cross_rhoV(population, populationNew, nlRhoV, rgen);
		population=populationNew;				
	}
	print_population_sample(Nsample, population);
	
	
	
	for(int i=0; i< nlRhoV.size(); i++){
		nlRhoV[i]=nlRhoV[i]/(double)N;
	}
	
	write_vector(outdir+"/inputRhoVec.txt", nlRhoV);
	
	return EXIT_SUCCESS;
}




							
					
 
							
	
