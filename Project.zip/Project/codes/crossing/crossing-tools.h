
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
#include <vector>
#include <string>
#include <algorithm>


#include <math.h>
#include <map>
#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>

using namespace std;

string form_recombinant(vector <int> &breakP, string seq1, string seq2);
void init_population(vector < std::string > &population, int N, int n_loci);

void init_population_frac(vector < std::string > &population, int N, int n_loci, double frac);

void print_population(vector < std::string > &population);

int pickFather(vector <double> &cprob);

void combined_resample_cross_rhoV(vector < std::string > &population, vector < std::string > &populationNew, vector <double> &nlRho, gsl_rng *gBaseRand);
void print_population_sample(int sample, vector < std::string > &population);

void write_parents(std::string name,vector < std::string > &population);

void init_population_4way(vector < std::string > &population, int N, int n_loci);

void init_population_4way_match(vector < std::string > &population, string parentsIn,int N, int n_loci);

void write_vector(std::string name, std::vector <double> &vec);
void read_rho(std::string fileIn, vector <double> &nlRhoV);