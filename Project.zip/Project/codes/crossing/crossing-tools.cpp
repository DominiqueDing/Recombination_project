#include "crossing-tools.h"


void write_vector(std::string name, std::vector <double> &vec){
	ofstream file;
	file.open(name.c_str());
	
	
	
	for(int i=0; i<vec.size(); i++){
		file << vec[i] << endl;
	}
	
	
	file.close();
}



void read_rho(std::string fileIn, vector <double> &nlRhoV){
	
	
	ifstream file;          
	file.open(fileIn.c_str());
	
	string haplotype;
	
	vector <double> locus;
	vector <double> rho;
	
	
	double s;
	
	
	do{
		
		file >> s;
		
		if(!file.eof())
			locus.push_back(s);
		
		file >> s;
		if(!file.eof())
			rho.push_back(s);
		
		
	}while (!file.eof());
	file.close();
	
	for(int i=1; i<rho.size(); i++){
		nlRhoV.push_back(rho[i-1]*(locus[i]-locus[i-1]));
	}
	
}



/* find on which interval a random number falls on a cumulative probability vector */
int pickFather(vector <double> &cprob){
	
	double rn=(double)(rand())/(double)(RAND_MAX);
	int k=0;
	while(k<cprob.size()){
		if(rn<cprob[k]){
			return k;
		}
		k++;
	}
	return -1; /* this should not happen*/  
}

/* this needs to be modified if more than two founder strains or unequal numbers of two parental strains form the inital pool */

void init_population(vector < std::string > &population, int N, int n_loci){
	
	std::string ones;
	std::string zeros;
	
	for(int l=0;l<n_loci; l++){
		ones.append("1");
		zeros.append("0");
	}

	for(int n=0;n<N/2; n++){
		population.push_back(ones);
		population.push_back(zeros);
	}
	
	vector < std::string > parents;
	
	parents.push_back(ones);
	//parents.push_back(ones);
	//parents.push_back(zeros);
	parents.push_back(zeros);
	
	write_parents("parental_seqs.fasta",parents);
	
}

void init_population_4way_match(vector < std::string > &population, string parentsIn,int N, int n_loci){
	
	std::string s1,s2,s3,s4;
	
	ifstream file;          
	file.open(parentsIn.c_str());
	
	string haplotype;
	string haplotype_name;
	
	double s;

	file >> s;
	file >> s;
	file >> s;
	file >> haplotype_name;
	file >> s1;
	file >> haplotype_name;
	file >> s2;
	file >> haplotype_name;
	file >> s3;
	file >> haplotype_name;
	file >> s4;	
	
	
	file.close();   
	
	
	
	
	for(int n=0;n<N/4; n++){
		population.push_back(s1);
		population.push_back(s2);
		population.push_back(s3);
		population.push_back(s4);
	}
	
	vector < std::string > parents;
	
	parents.push_back(s1);
	parents.push_back(s2);
	parents.push_back(s3);
	parents.push_back(s4);
	
	
	write_parents("parental_seqs.fasta",parents);
	
}




void init_population_4way(vector < std::string > &population, int N, int n_loci){
	
	std::string ones;
	std::string s1,s2,s3,s4;
	
	
	for(int l=0;l<n_loci; l++){
		ones.append("1");
	}
	s1=ones; /* parent one carries allways allele one */
	double rn;
	
	for(int l=0;l<n_loci; l++){
		rn=(double)(rand())/(double)(RAND_MAX);
		if(rn < 0.5){
			s2.append("1");
		}
		else{
			s2.append("0");
		}
	}
	for(int l=0;l<n_loci; l++){
		rn=(double)(rand())/(double)(RAND_MAX);
		if(rn < 0.5){
			s3.append("1");
		}
		else{
			s3.append("0");
		}
	}
	for(int l=0;l<n_loci; l++){
		rn=(double)(rand())/(double)(RAND_MAX);
		if(rn < 0.5){
			s4.append("1");
		}
		else{
			s4.append("0");
		}
	}
	
	for(int n=0;n<N/4; n++){
		population.push_back(s1);
		population.push_back(s2);
		population.push_back(s3);
		population.push_back(s4);
	}
	
	vector < std::string > parents;
	
	parents.push_back(s1);
	parents.push_back(s2);
	parents.push_back(s3);
	parents.push_back(s4);
	
	
	write_parents("parental_seqs.fasta",parents);
	
}


void init_population_frac(vector < std::string > &population, int N, int n_loci, double frac){
	
	std::string ones;
	std::string zeros;
	
	for(int l=0;l<n_loci; l++){
		ones.append("1");
		zeros.append("0");
	}
	
	for(int n=0;n<N*frac; n++){
		population.push_back(ones);
	}
	for(int n=0;n<N*(1.0-frac); n++){
		population.push_back(zeros);
	}
	
	int Ntot=population.size();
	
	while(Ntot<N){
		population.push_back(zeros);
		Ntot=population.size();
	}
	
}

/* print a random sample of haplotypes (with replacement)  in a format which can be read by LDhat */
void print_population_sample(int sample, vector < std::string > &population){
	
	int N=population.size();
	int n_loci=population[0].size();
	
	cout << sample <<" "<< n_loci << " 1" << endl;
	
	
	for(int n=0; n<sample; n++){
	
		double rn=(double)(rand())/(double)(RAND_MAX);
		
		int ri=(int)(rn*(double)(N));
		
		cout << ">seq"<<n<<"\n";
		cout << population[ri] << endl;

	}
	
	
}

void write_parents(std::string name,vector < std::string > &population){
	
	ofstream file;
	file.open(name.c_str());
	
	int N=population.size();
	int n_loci=population[0].size();
	
	file << N <<" "<< n_loci << " 1" << endl;
	
	for(int n=0; n<N; n++){
		file << ">seq_parent"<<n << endl;
		file << population[n] << endl;
	}
	file.close();
		
}

/* draw new generation with replacement and recombine with recombination profile rhoV */

void combined_resample_cross_rhoV(vector < std::string > &population, vector < std::string > &populationNew, vector <double> &nlRho, gsl_rng *gBaseRand){
	
	
	int N=population.size();
	int n_loci=population[0].size();
	
	std::string recombinant1;
	std::string recombinant2;
	std::string recombinant1N;
	std::string recombinant2N;
	
	int k=0;
	
	double nlRhoZ=0.0;
	
	for(int i=0; i< nlRho.size(); i++){
		nlRhoZ+=nlRho[i];
	}
	
	vector <double> cumProb(nlRho.size());
	
	
	cumProb[0]=nlRho[0];
	for(int i=1; i< nlRho.size(); i++){
		cumProb[i]=nlRho[i]+cumProb[i-1];
	}
	
	for(int i=0; i< nlRho.size(); i++){
		cumProb[i]=cumProb[i]/nlRhoZ;
		
	}
	
	for(int n=0; n< N/2; n++){
		
		double rn=(double)(rand())/(double)(RAND_MAX);
		int ind1=(int)(rn*(double)(N));
		
		rn=(double)(rand())/(double)(RAND_MAX);
		int ind2=(int)(rn*(double)(N));
		
		
		recombinant1=population[ind1];
		recombinant2=population[ind2];
		
		recombinant1N=recombinant1;
		recombinant2N=recombinant2;
	
		/* this many events to be distributed */
		
		int nEvents=(int)gsl_ran_poisson(gBaseRand,nlRhoZ/(double)N);
		
		vector <int> breakP;
		
		breakP.clear();
		
		for(int ri=0; ri<nEvents; ri++){
			/* get a random break point */			
			double rn=(double)(rand())/(double)(RAND_MAX);
			int rx=pickFather(cumProb);
			breakP.push_back(rx+1);
		}
		breakP.push_back(n_loci);
		
		
		recombinant1N=form_recombinant(breakP,recombinant1,recombinant2);
		recombinant2N=form_recombinant(breakP,recombinant2,recombinant1);
		
		populationNew[k++]=recombinant1N;
		populationNew[k++]=recombinant2N;
		
		
	}
	
}

string form_recombinant(vector <int> &breakP, string seq1, string seq2){

	string recombinant;
	recombinant=seq1;
	
	sort(breakP.begin(), breakP.end());
	for(int ri=1; ri<breakP.size(); ri=ri+2){
		for(int l=breakP[ri-1]; l < breakP[ri]; l++){
			recombinant[l]=seq2[l];
		}
	}	
	return recombinant;
	
};








