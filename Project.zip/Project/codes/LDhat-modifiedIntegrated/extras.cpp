
//#include "seqtools.h"
//#include "tools.h"
#include "ldhat.h"
#include "extras.h"


void read_parental_fractions(std::vector<double>& parents, std::string infile){
	
	ifstream pass_file;             
	pass_file.open(infile.c_str());
	double x=0;	
	
	while (!pass_file.eof()){
		if(x>0.0001){
			parents.push_back(x);
		}
		pass_file >> x;
	}
	
	double z=0;
	
	for(int i=0; i<parents.size(); i++){
		z+=parents[i];
	}
	
	if(fabs(z-1.0)>0.001){
		cout << "Parental fractions do not add to one!\n";
		exit(0);
	}{
		cout <<"Successfully read in fractions of " << parents.size() << " parents\n";  
	}
	
}


void create_lk(site_type **npset, int ntypes, double **lkmat, vector <double> &rhoV, vector<initial_condition> &init, int Ncrosses){
	
	//vector <double> ll;
	
	extern int sizeofpset;
	
	vector <int> obs;
	
	for(int t=1; t<=ntypes; t++){
		obs.clear();
		
		/* observation of two locus haplotypes*/
		for(int k=0; k<4; k++){
			obs.push_back(npset[t]->pt[k]);
		}
		int linkage_index=npset[t]->pt[9];
		
		vector <double> q;
		if(linkage_index>=0 && linkage_index<init.size()){
			for(int ri=0; ri<rhoV.size(); ri++){
				get_qvector_general(init[linkage_index].x1,init[linkage_index].y1,init[linkage_index].d0ij,Ncrosses,rhoV[ri],q);
				
				lkmat[t][ri+1]=log_likelihood(obs,q);
				
				
			}
		}
		else{
		
			if(linkage_index==-1){
				for(int ri=0; ri<rhoV.size(); ri++){
					lkmat[t][ri+1]=-0.001*ri;
					cout << "Should not happen now" <<  linkage_index << "\n"; 
					exit(0);
				}
			}
			else{
				cout << "Undefined pair type" <<  linkage_index << "\n"; 
				exit(0);
			}
		}
		//cout << "Pair_type "<<t<< " ready from "<<sizeofpset <<" \n";  
	}
}


/* Infinite population size approximation for the two locus genotype frequencies undergoing recombination for Ncrosses generations */
void get_qvector_general(double x1, double y1, double d0ij, int Ncrosses, double rho, vector < double> &q){
	
	double eps=0.001;
	double x0,y0;
	
	x0=1.0-x1;
	y0=1.0-y1;
	
	//double dijmax=min(x0*y1,x1*y0);
	double dij;
	
	/* rho=1/2 equals free recombination */
	dij = d0ij*pow((1.0 - min(0.5, rho)), (double)Ncrosses);
	
	q.clear();
	q.push_back(y0*x0 + dij); // q00;
	q.push_back(x0*y1 - dij); // q01;
	q.push_back(x1*y0 - dij); // q10;
	q.push_back(x1*y1 + dij); // q11;
	
	/* for zero entries add epsilon and renormalize accordingly to avoid -infinities in the log likelihood for zero recombination case */
	for(int i=0; i< q.size(); i++){
		if(q[i]<eps){
			q[i]=eps;
		}
	}
	double z=0.0;
	for(int i=0; i< q.size(); i++){
		z+=q[i];
	}
	for(int i=0; i< q.size(); i++){
		q[i]=q[i]/z;
	}
	
};

/* probability of observing counts Nv given a true frequency vector q */

double log_likelihood(vector <int> &Nv, vector < double> &q){
	
	double p[Nv.size()];
	unsigned int n[Nv.size()];
	
	for(int i=0; i<Nv.size(); i++){
		p[i]=q[i];
		n[i]=Nv[i];
	}
	double ll=gsl_ran_multinomial_lnpdf (Nv.size(),p,n);
	return ll;
}


void convert_initial_conditions_set(set < std::string > &init, vector <initial_condition> &init_cond){
	
	set<std::string>::iterator it;
	init_cond.clear();
	for (it=init.begin(); it!=init.end(); it++){
		
		initial_condition ic;
		
		convert(*it, &ic);
		//cout << *it << "\n";
		//cout << ic.x1 << " "<< ic.y1 << " "<< ic.d0ij << "X\n";
		init_cond.push_back(ic);
	}
	
}

void create_initial_conditions_general(vector <initial_condition> &init_cond, vector<double> &parents){
	
	set < std::string > init;
	
	std::string s1;
	
	//s1.append("11"); /* this we can choose for one parent without a loss of generality */
	
	int nFounders=parents.size();
	
	
	vector < std::string > pairs;
	
	/* all possible two locus two alleles haplotypes */
	pairs.push_back("11");
	pairs.push_back("10");
	pairs.push_back("01");
	pairs.push_back("00");
	
	
	/* all possible initial conditions given nFounders*/
	int Nall=(int)pow(4.0,(double)(nFounders));
	
	
	for(int k=0; k<Nall; k++){
		vector < std::string > obs;
		obs.clear();
		
		//obs.push_back(s1);
		//cout << k <<" "<< s1 << " ";
		
		int div=Nall;
		for(int p=0; p<nFounders; p++){
			
			div=div/4;
			
			int kk=(k/div)%4;
			
			//cout << pairs[kk] << " ";
			obs.push_back(pairs[kk]);
		}
		//cout << "\n";
		
		struct initial_condition ic;
		string index=eval_init_general(&ic,obs,parents);
		
		if(index != "-1"){
			init.insert(index);
		}
		
	}
	
	convert_initial_conditions_set(init,init_cond);
	
	
	
}


std::string eval_init_general(initial_condition *ic, vector <std::string >&obs, vector <double >&parents){
	
	double xi=0;
	double yi=0;
	
	double dij;
	double q0[4];
	
	for(int i=0; i<4; i++){
		q0[i]=0.0;
	}
	
	
	for(int i=0; i< parents.size(); i++){
		if(obs[i][0]=='1'){
			xi+=parents[i];
		}
		if(obs[i][1]=='1'){
			yi+=parents[i];
			
		}
		
		// q00;
		// q01;
		// q10;
		// q11;
		
		if(obs[i]=="00"){
			q0[0]+=parents[i];
		}
		if(obs[i]=="01"){
			q0[1]+=parents[i];
		}
		if(obs[i]=="10"){
			q0[2]+=parents[i];
		}
		if(obs[i]=="11"){
			q0[3]+=parents[i];
		}
		
	}
	
	dij=q0[0]*q0[3]-q0[1]*q0[2];
	
	stringstream ss;
	ss << xi << " "<< yi << " " << dij;
	//cout << xi << " " << yi << " "<< dij << endl; 
	
	//if(xi<1.0 && yi<1.0){
		return ss.str();
	//}
	//else{
	//	return "-1";
	//}
	

}



void convert(string ss, initial_condition *init){
	std::istringstream is(ss);
    double nn;
	is >> nn;
	init->x1=nn;
	is >> nn;
	init->y1=nn;
	is >> nn;
	init->d0ij=nn;	
}



/* Routine to classify each pairwise comparison initial condition*/

int get_inital_linkage_index(int **seqs, int i, int j, vector<initial_condition> &init, vector<double> &parents){
	
			
	vector <double> q(4);
	for(int i=0; i<4; i++){
		q[i]=0.0;
	}
	
	for(int n1=1; n1<=parents.size(); n1++){
	
		if(seqs[n1][i]==2 && seqs[n1][j]==2){//00
			q[0]+=parents[n1-1];
		}
		if(seqs[n1][i]==2 && seqs[n1][j]==3){//01
			q[1]+=parents[n1-1];
		}
		if(seqs[n1][i]==3 && seqs[n1][j]==2){//10
			q[2]+=parents[n1-1];
		}
		if(seqs[n1][i]==3 && seqs[n1][j]==3){//11
			q[3]+=parents[n1-1];
		}
	}
	
	double dij=q[3]*q[0]-q[1]*q[2];
	double xi=q[3]+q[2];
	double yi=q[3]+q[1];
	
	double eps=0.0001;
	
	/* now classify the pair in terms of the parental pool two locus information*/	
	for(int k=0; k<init.size(); k++){
		if(fabs(xi - init[k].x1)<eps && fabs(yi - init[k].y1)<eps && fabs(dij - init[k].d0ij)<eps){
			return k;
		}
	}
	
	cout << xi <<" "<< yi <<" "<< dij <<"\n";
	exit(0);
	
	return -1;
	
}


