#if !defined SEQTOOLS_H
#define SEQTOOLS_H

//#include <stdlib.h>
//#include <stdio.h>
//#include <math.h>

#include <stdlib.h>
#include <stdio.h>
#include <math.h>




#include "ldhat.h"
#include "tools.h"
#include "seqtools.h"
#include "extras.h"

//int read_fasta();
//void allele_count();
//float watterson();
//int check22();
//
//struct site_type ** pair_spectrum();
//
//
//int add_type();
//void print_pairs();
//int * order_pt_hap();
//int * order_pt_dip();
//void type_print();
//void read_pt();
//
//
//
//struct site_type ** init_pset();
//struct site_type ** add_pset();
//void read_pars();
//void read_lk();
//
//
//int add_type2();
//void print_pairs2();
//void read_pt2();
//int get_inital_linkage_index(int **seqs, int i, int j);
//struct site_type ** pair_spectrum2();
//int draw_new(double p[4], int type);


int read_fasta(int **seqs, FILE *ifp, int nseq, int lseq, char **seqnames);
void allele_count(int **seqs,int nseq,int lseq, int **nall,int fl, int hd);
float watterson(int n);
int check22(int s1,int s2,int **nall);


//struct site_type ** pair_spectrum2(int **seqs_init,int **seqs,data_sum *data,int **nall,site_type **pset,int *npt,int *pnew,int *miss,int anc,int **pij);

int add_type2(site_type **pset,int *cpt,int *ntc,int *pnew,int *miss,data_sum *data);
void print_pairs2(FILE *ofp,site_type **pset,int nt,int hd, int nseq);
int * order_pt_hap(int *pt,int nseq);
int *order_pt_dip(int *pt,int nseq);
void type_print(int **pij,int lseq,int w,FILE *ofp);
void read_pt2(FILE *ifp,site_type **pset,int *npt,data_sum *data);

struct site_type ** init_pset(site_type **pset,int lkf,FILE *ifp,int *npt,data_sum *data);
struct site_type ** add_pset(site_type ** pset);
void read_pars(FILE *ifp,int *tcat,float *theta,int *rcat,float *rmax);
void read_lk(FILE *ifp,double **lkmat,int npt,int tcat,int rcat);


//struct site_type ** pair_spectrum_eval_realtime(int **seqs_init,int **seqs,data_sum *data,int **nall,site_type **pset,int *npt,int *pnew,int *miss,int anc,int **pij);

//struct site_type ** pair_spectrum2(int **seqs_init,int **seqs,data_sum *data,int **nall,site_type **pset,int *npt,int *pnew,int *miss,int anc,int **pij, vector<initial_condition> &init);
struct site_type ** pair_spectrum2(int **seqs_init,int **seqs,data_sum *data,int **nall,site_type **pset,int *npt,int *pnew,int *miss,int anc,int **pij, vector<initial_condition> &init, vector<double> &parents);


#endif


