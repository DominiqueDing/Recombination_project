#if !defined TOOLS_H
#define TOOLS_H

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <time.h>

//float *vector();
//float **matrix();
//double *dvector();
//double **dmatrix();
//int *ivector();
//int **imatrix();
//char **cmatrix();
//void free_vector();
//void free_dvector();
//void free_ivector();
//void free_matrix();
//void free_dmatrix();
//void free_imatrix();
//void free_cmatrix();
//void nrerror();
//int mini();
//int maxi();
//float minc();
//float minf();
//float maxf();
//float lnfac();
//void pswap();
//float lognC2();
//float lognC4();
//void sort();
//long setseed();
//float ran2();



void nrerror(char error_text[]);
float *fvector(int nl,int nh);
int *ivector(int nl,int nh);
double *dvector(int nl,int nh);
float **matrix(int nrl,int nrh,int ncl,int nch);
double **dmatrix(int nrl,int nrh,int ncl,int nch);
int **imatrix(int nrl,int nrh,int ncl,int nch);
char **cmatrix(int nrl,int nrh,int ncl,int nch);
void free_vector(float *v,int nl, int nh);
void free_ivector(int *v,int nl,int nh);
void free_dvector(double *v,int nl,int nh);
void free_matrix(float **m,int nrl,int nrh,int ncl,int nch);
void free_dmatrix(double **m,int nrl,int nrh,int ncl,int nch);
void free_imatrix(int **m,int nrl,int nrh,int ncl,int nch);
void free_cmatrix(char **m,int nrl,int nrh,int ncl,int nch);

int mini(int i,int j);
int maxi(int i,int j);
float minf(float f1, float f2);
float maxf(float f1, float f2);
float lnfac(int i);
float minc(float l1,float l2,float ls);
void pswap(int *pt, int s1,int s2);

float lognC2(int n,int a);
float lognC4(int n,int a,int b,int c,int d);
void sort(float *array, int ne);
long setseed(void);
float ran2(void);



#endif


