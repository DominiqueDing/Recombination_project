#if !defined EXTRAS_H
#define EXTRAS_H

#include <iostream>
#include <sstream>
#include <vector>
#include <list>
#include <deque>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
#include <vector>
#include <string>
#include <algorithm>


#include <math.h>
#include <map>
#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>

#include <set>

#include "ldhat.h"
//#include "tools.h"
//#include "seqtools.h"
#include "extras.h"


using namespace std;

struct initial_condition{
	double x1;
	double y1;
	double d0ij;
};



//void create_lk(site_type **npset, double **lkmat);

//int draw_new(double p[4], int type);


void create_lk(site_type **npset, int ntypes, double **lkmat, vector <double> &rhoV, vector<initial_condition> &init, int Ncrosses);

void convert_initial_conditions_set(set < std::string > &init, vector <initial_condition> &init_cond);

void create_initial_conditions_general(vector <initial_condition> &init_cond, vector <double> &parents);

void read_parental_fractions(std::vector <double> &parents, std::string infile);

std::string eval_init_general(initial_condition *ic, vector <std::string >&obs, vector <double >&parents);

void convert(string ss, initial_condition *init);

void get_qvector_general(double x1, double y1, double d0ij, int Ncrosses, double rho, vector < double> &q);
double log_likelihood(vector <int> &Nv, vector < double> &q);

int get_inital_linkage_index(int **seqs, int i, int j, vector<initial_condition> &init, vector<double> &parents);


#endif