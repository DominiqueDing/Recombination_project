#!/bin/bash

set -e
#test if customisation has already performed
if test -e customise.log; then
	echo "It has already been run, check the files!"
	exit 1
fi

#if not create logfile to mark it
echo "----------------------------------------------------------------" >>customise.log
echo "----------------------------------------------------------------" >>customise.log
date>>customise.log
echo "Running customise.sh" >> customise.log
#customise
CUSTOM=`pwd | awk -F '/' '{print $NF}'`

sed -i  -e "s/2way_v4_interval/2way_v4_interval_${CUSTOM}/" -e "s/inference_results_example/inference_results_example_${CUSTOM}/" example-inference.0.sh

sed -i -e "s/scripts_inference/${CUSTOM}/" slurm_submit.0.darwin
