#!/bin/bash
declare -i index_id

for index_id in {1..100}
do
cp example-inference.0.sh example-inference.${index_id}.sh
done
