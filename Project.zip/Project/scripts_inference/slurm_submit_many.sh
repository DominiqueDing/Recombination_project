#!/bin/bash

./generate_multiple_scripts.sh
./generate_multiple_subscripts.sh

#make logfile
echo "-------------------------------------------------------------" >>../submitting_job.log
echo "-------------------------------------------------------------" >>../submitting_job.log
date >> ../submitting_job.log
echo `pwd` >>../submitting_job.log
#submitting jobs
declare -i i
for i in {1..100}
do
sbatch slurm_submit.${i}.darwin
done
#make logfile
squeue -u sd768 >> ../submitting_job.log


