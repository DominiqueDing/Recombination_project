#!/usr/bin/perl -w
use strict;
use Getopt::Std;

$,= "";

my %OPTS;
getopts('i:o:s:',\%OPTS);

my $in_file1 = $OPTS{i};
my $out_seq = $OPTS{o};
my $seed = $OPTS{s};

srand($seed);

my @seqs;
my @tags;

my $lc=0;
my $header;
open my $IN_FILE, '<', $in_file1 or die "Cannot open  input file";
foreach my $line (<$IN_FILE>) {
  chomp($line);
  
  if($lc==0){
  	$header=$line;	
  }else{
  	 
  if($line =~ />/){
    push(@tags,$line);
   }
  else{
    push(@seqs,$line);
  }
  }
  $lc++;
} 
close $IN_FILE;

if(scalar (@seqs) ne scalar(@tags)){
print "Differing numbers of tags and sequences", scalar(@seqs),scalar(@tags),"\n";	
}

my $l=scalar(@seqs);

open my $OUT_FILE, '>', $out_seq or die "Cannot open output file";
print $OUT_FILE $header, "\n";
for(my $i=0;$i< $l; $i++){
	my $ind=int(rand($l));
	print $OUT_FILE $tags[$ind],"\n";
	print $OUT_FILE $seqs[$ind],"\n";
}
close $OUT_FILE;




