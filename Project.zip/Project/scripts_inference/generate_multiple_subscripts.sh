#!/bin/bash
declare -i i
for i in {1..100}
do
sed "s/example-inference.0.sh/example-inference.${i}.sh/" <slurm_submit.0.darwin >slurm_submit.${i}.darwin
chmod a+x slurm_submit.${i}.darwin
done
