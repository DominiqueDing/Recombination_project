/*
read in aligned seq_file out put the unaligned seq_file
in unaligned seq_file:
number_of_sequences number_of_segregation_sites LD_index
>seq_
#seq_loc_begin seg_loc_end
1111111111110000000000000000
................
................
./make_not_aligned <input_seq_file> <out_put_seq_file>
*/
#include <fstream>
#include <stdio.h>
#include <string>
#include <sstream>
#include <vector>
using namespace std;

int main(int argc,char ** argv){
	ifstream in_seq(argv[1]);
	ofstream out_seq(argv[2]);
	string line;
	int ct=0;
	while(getline(in_seq,line)){
		if(line.front()=='>'){
			out_seq<<line<<'\n';
		}
		else{
			ct++;
			if(ct==1){
				out_seq<<line<<'\n';
			}
			else{
				stringstream line_ss;
				line_ss<<line;
				vector<int> seg_loc_v;
				vector<char> seq;
				int seg_loc_i=0;
				char loc;
				while(line_ss>>loc){
					seg_loc_i++;
					if(loc!='N'){
						seg_loc_v.push_back(seg_loc_i);
						seq.push_back(loc);
					}
				}
				out_seq<<'#';
				for(int i=0;i<seq.size();i++){
					out_seq<<seg_loc_v[i]<<' ';
				}
				out_seq<<'\n';
				for(int i=0;i<seq.size();i++){
					out_seq<<seq[i];
				}
				out_seq<<'\n';
				seg_loc_v.clear();
				seq.clear();
			}
		}
		line.clear();
	}
}
