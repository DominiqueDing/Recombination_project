/*
./make_aligned <input_seq_file> <out_put_seq_file>
*/
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
#include <vector>
#include <string>
#include <algorithm>
#include <map>
#include <sstream>
#include <fstream>
#include <stdio.h>
#include <math.h>
using namespace std;

struct seqs {
  vector<char> loci;//read (0 or 1) of each loci 
  string seq_header_str;//header of the sequence;
};

int main(int argc, char ** argv){
	//get header, header[0]=number_of_sequences, header[1]=number_of_segregation_sites, header[2]=LDhat_index
	vector<int> header(3);
	FILE * ifpheader;
	ifpheader=fopen(argv[1],"r");
	fscanf(ifpheader, "%i %i %i", &header[0],&header[1],&header[2]);
	fclose(ifpheader);

	//read in
	vector< struct seqs > samples(header[0]);
	for(int i=0;i<samples.size();i++){
		do{samples[i].loci.push_back('N');}
		while(samples[i].loci.size()<header[1]+1);
	}
	ifstream in_seq(argv[1]);
	string line;
	int ct=0;
	while(getline(in_seq,line)){
		ct++;
		if(ct>1){
			int index=floor((double)(ct-2)/(double)3);
			if(line.front()=='>'){
				samples[index].seq_header_str.assign(line.begin(),line.end());
			}
			else if(line.front()=='#'){
				line.erase(line.begin());
				stringstream line_ss;
				line_ss<<line;
				int seg_loc;
				while(line_ss>>seg_loc){
					samples[index].loci[seg_loc-1]='Y';
				}
			}
			else {
				int ct_loci=0;
				for(int i=0; i<samples[index].loci.size();i++){
					if(samples[index].loci[i]=='Y'){
						samples[index].loci[i]=line[ct_loci];
						ct_loci++;
					}
				}
			}
		}
	}
	//out put
	ofstream out_seq(argv[2]);
	out_seq<<header[0]<<' '<<header[1]<<' '<<header[2]<<'\n';
	for(int i=0; i<samples.size();i++){
		out_seq<<samples[i].seq_header_str<<'\n';
		for(int ii=0; ii<header[1]; ii++){
			out_seq<<samples[i].loci[ii];
		}
		out_seq<<'\n';
	}
}

