$ make
$./sim_nanolen <seed> <input_sequence_reads_file> <output_sequence_reads_file>

This program simulate nanopore read length based on input file. 
In the output file, for informative segments in each reads, their lengths are of nanopore read length distribution, the rest loci are non-informative, as 'N'. 