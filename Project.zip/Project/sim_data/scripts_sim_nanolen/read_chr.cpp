//input chr
#include  "shared.h"

void ReadChr ( vector<double>& chr){

  string line;
  double d;
  ifstream in_file("chr3.seg.loc");
  int count=0;

  while(getline(in_file,line)){
    count++;
    if (count==2){
      stringstream line_ss;
      line_ss<<line;
      while(line_ss>>d){
        chr.push_back(d);
      }
    }
  }
}



