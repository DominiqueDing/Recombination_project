/*
$ make
$./sim_nanolen <seed> <threshold> <input_sequence_reads_file> <output_sequence_reads_file>

here threshold is the cumulative Pr of a length
*/
#include "shared.h"
using namespace std;

int main (int argc, const char ** argv){
	//Set up random number generator
    int seed=atoi(argv[1]);
    gsl_rng_env_setup();
    gsl_rng *rgen = gsl_rng_alloc (gsl_rng_taus);
    gsl_rng_set (rgen, seed);

	//set up threshold, here threshold is the cumulative Pr of a length
	long double threshold=atof(argv[2]);

    //Read in chr
    vector<double> chr3;
    ReadChr(chr3);
//cout<<"chr3size"<<chr3.size()<<'\n';

    //Read in Protocal
    struct withPr Protocal;
    ReadProtocal(Protocal);
//cout<<"Protocal.lenPr.size"<<Protocal.lenPr.size()<<'\n';

    //create samples of type <sequences> to store read
    struct sequences samples;

    string out_title_str=argv[4];
    remove(out_title_str.c_str());
    ofstream outfile(argv[4], ios::app);
	ifstream infile(argv[3]);
	string line;
	int count=0;
	while(getline(infile, line)){
		if(*line.begin()=='>'){
			outfile<<line<<'\n';
		}
		else{
			count++;
			if(count==1){
				outfile<<line<<'\n';
			}
			else{
				char b;
				stringstream line_ss;
				line_ss<<line;
				while(line_ss>>b){
					samples.parentinfo.push_back(b);
				}
				//cout<<samples.parentinfo.size()<<'\n';
				samples.actposi.assign(chr3.begin(),chr3.end());
				
				//generate read length for this read:
				double readlength;
				long double rl;//to compare with cumulative pr.
				do{
					rl=gsl_rng_uniform(rgen)*1;
				}
				while(rl<threshold);//relate to previously set threshold;
//cout<<"rl: "<<rl<<'\n';
				int n=0;
				do{
				  readlength=Protocal.length[n];
				  ++n;
			    }
			    while(rl>=Protocal.lenPr[n]);
				double start, end;
				start=(floor(gsl_rng_uniform(rgen)*(365000-readlength*1000)))*0.001+1;
				end=start+readlength;
				samples.range.push_back(start);
				samples.range.push_back(end);//now that samples has range.

				int startpoint;
				if(start<=samples.actposi.front()){
				  startpoint=0;
				}
				else if(start>samples.actposi.back()){
				  startpoint=samples.actposi.size();
				}
				else{
					for(int point=1;point<samples.actposi.size();point++){
				    	if((start>samples.actposi[point-1])&(start<=samples.actposi[point])){
				      	 startpoint=point;
				    	}
				    }
				}

			    int endpoint;
				if(end<samples.actposi.front()){
					endpoint=0;
				}
				else if(end>=samples.actposi.back()){
					endpoint=samples.actposi.size();
				}
				else{
					for(int point=1;point<samples.actposi.size();point++){
				    	if((end>=samples.actposi[point-1])&(end<samples.actposi[point])){
				        	endpoint=point;
				    	}
				    }
				}
				//cout<<startpoint<<' '<<endpoint<<'\n';

				for(int i=0; i<startpoint; i++){
					samples.parentinfo[i]='N';
				}
				for (int i =endpoint; i<samples.parentinfo.size(); ++i){
					samples.parentinfo[i]='N';
				}

				//Output to file:
				for(int i=0; i<samples.parentinfo.size(); ++i){
					outfile<<samples.parentinfo[i];
				}
				outfile<<'\n';
				samples.parentinfo.clear();
			}
		}
	}
}
