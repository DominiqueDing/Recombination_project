/*
Replace any base with Phredscore<threshold_Phredscore with N, requires seq_file(records sequence reads), and corrresponding Q_file(records corresponding Phred scores)
> in scripts/
$./plugin_N <threshold> <seq_file_to_be_modified> <out_put_seq_file(with_added_N)>
*/
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
#include <vector>
#include <string>
#include <algorithm>
#include <map>
#include <sstream>
#include <fstream>
#include <stdio.h>
#include <math.h>

using namespace std;

struct seqs {
  vector<char> loci;//read (0 or 1) of each loci 
  vector<int> Q; //Phredscore of each loci
  string seg_loc_str;//segregation sites of each loci
  string seq_header_str;//header of the sequence;
};

int main(int argc, const char **argv) {

  //set up the threshold for errors (in Q_number forms):
  int threshold=atoi(argv[1]);

  //sort out all the files:
  string in_seq_title=argv[2];
  string Qfile_title=in_seq_title+".Q";
  string out_seq_title=argv[3];
  ifstream in_seq(in_seq_title);//seq_file to be modified
  ifstream Qfile(Qfile_title);//Qfile corresponding to the original seq_file
  remove(out_seq_title.c_str());
  ofstream out_seq(out_seq_title);//modified seq_file with added N

  //collect header
  vector<int> header;
  ifstream if_header(argv[2]);
  int h;
  while(if_header>>h){
	header.push_back(h);
 }

  //
  vector< struct seqs > samples(header[0]);
  int ct=0;
  string line;
  while(getline(in_seq,line)){//collect 
	ct++;
	if(ct>1){
		int index=floor((double)(ct-2)/(double)2);
		if(line.front()=='>'){
			samples[index].seq_header_str.assign(line.begin(),line.end());
		}
		else if(line.front()=='#'){
			samples[index].seg_loc_str.assign(line.begin(),line.end());
		}
		else if(!line.empty()){
			stringstream line_ss;
			line_ss<<line;
			char base;
			while(line_ss>>base){
				//cout<<base<<' ';////////////////////////////////
				samples[index].loci.push_back(base);		
			}
		}
	}

  }
  line.clear();
  ct=0;
  while(getline(Qfile,line)){
	if((line.front()!='>')&(line.front()!='#')){
		ct++;
		if((ct>1)&(!(line.empty()))){
			stringstream line_ss;
			line_ss<<line;
			int score;
			while(line_ss>>score){
				samples[ct-2].Q.push_back(score);		
			}			
		}
	}
  }

  //plug in N 
  for(int i=0;i<samples.size();i++){
        //cout<<samples[i].loci.size()<<' '<<samples[i].Q.size()<<'\n';/////////////////////////////////////////////////
	for(int ii=0;ii<samples[i].loci.size();ii++){
		if(samples[i].Q[ii]<threshold){
			samples[i].loci[ii]='N';
		}
	}
  }

  //out put
  out_seq<<header[0]<<' '<<header[1]<<' '<<header[2]<<'\n';
  for(int i=0;i<samples.size();i++){
	if(!samples[i].seg_loc_str.empty()){out_seq<<samples[i].seg_loc_str<<'\n';}
	out_seq<<samples[i].seq_header_str<<'\n';
	for(int ii=0; ii<samples[i].loci.size();ii++){
		out_seq<<samples[i].loci[ii];
	}
	out_seq<<'\n';
  } 










/*
  out_seq<<header[0]<<' '<<header[1]<<' '<<header[2]<<'\n';  
  for(int seq=0;seq<header[0];seq++){
	struct seqs sample;
	//get base read for smaple.loci[] and seg_loc_v
	int count=0;
	string line;
	ifstream in_seq;
	in_seq.open(in_seq_title);
	while(getline(in_seq,line)){
		if(line.front()=='>'){//get seq_header_str
			sample.seq_header_str.assign(line.begin(),line.end());
			//cout<<sample.seq_header_str<<'\n';/////////////////////////////////////////
		}
		else{//get loci
			count++;
			if((count==seq+2)&!(line.empty())){
				stringstream line_ss;
				line_ss<<line;
				char base;
				while(line_ss>>base){
					sample.loci.push_back(base);		
				}
			}
		}
	}
	//get Q for smaple.Q[]
	count=0;
	line.clear();
	ifstream Qfile;
	Qfile.open(Qfile_title);
	while(getline(Qfile,line)){
		if((line.front()!='>')&(line.front()!='#')){
			count++;
			if((count==seq+2)&!(line.empty())){
				stringstream line_ss;
				line_ss<<line;
				int score;
				while(line_ss>>score){
					sample.Q.push_back(score);		
				}
			}
		}
	}
	//plug in N for sample.loci[]
	for(int i=0;i<sample.loci.size();i++){
		if(sample.Q[i]<threshold){
			sample.loci[i]='N';
		}
	}
	//out_put sample.loci[] to out_seqfile
	out_seq<<sample.seq_header_str<<'\n'<<sample.seg_loc_str<<'\n';
	for(int i=0;i<sample.loci.size();i++){
		out_seq<<sample.loci[i];
	}
	out_seq<<'\n';
	
	sample.loci.clear();
	sample.Q.clear();
	sample.seq_header_str.clear();
	sample.seg_loc_str.clear();
  }  
*/
  
  return 0;
}
