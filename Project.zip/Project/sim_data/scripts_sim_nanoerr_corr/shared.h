#ifndef SHARED_H
#define SHARED_H


#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
#include <vector>
#include <string>
#include <algorithm>
#include <map>
#include <set>
#include <sstream>
#include <fstream>
#include <stdio.h>
#include <math.h>


using namespace std;

struct snp {  //Unit for sparse storage of variants
	int loc;
	char nuc;
};

#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>
#include <gsl/gsl_vector.h>
#include <gsl/gsl_matrix.h>
#include <gsl/gsl_blas.h>
#include <gsl/gsl_multifit_nlin.h>
#include <gsl/gsl_sf_hyperg.h>
#include <gsl/gsl_sf_gamma.h>
#include <gsl/gsl_randist.h>
#include <gsl/gsl_histogram.h>
#include <gsl/gsl_statistics_double.h>
#include <gsl/gsl_permutation.h>
#include <gsl/gsl_math.h>
#include <gsl/gsl_linalg.h>
#include <gsl/gsl_multimin.h>

#include "withPr.h"
#include "sequences.h"

void makelog_input_error (int & argc, const char** & argv);
void makelog_corr (int & argc, const char** & argv);
void Shadow (vector<char>& seq, vector<char>& shadow);
void ReadProtocal (withPr& Protocal);

#endif //SHARED_H


