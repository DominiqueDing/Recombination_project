#ifndef WITHPR_H
#define WITHPR_H

#include <vector>
using namespace std;

	struct withPr {
		vector<double> length;
		vector<char> Phred;
		vector<int> Phred_number;
        vector<long double> lenPr;
        vector<long double> PhredPr;
    };
#endif //WITHPR_H