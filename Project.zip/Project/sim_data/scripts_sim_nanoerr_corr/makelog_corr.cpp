#include <stdio.h>
#include <time.h>
#include <fstream>

using namespace std;

	void makelog_corr (int & argc, const char**  & argv){
		ofstream log("corr_error.log",ios::app);
		time_t rawtime;
		time(&rawtime);
		log<<"-----------------------------------------------------"<<'\n';
		log<<"-----------------------------------------------------"<<'\n';
		log<<ctime(&rawtime)<<'\n';
		log<<">running command:\n";
		for(int i=0;i<argc; i++){
			log<<argv[i]<<' ';
		}
		log<<'\n';
		log<<endl;
	}