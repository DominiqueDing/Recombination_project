/*
> in scripts/
$make 
$./corr_singleflips <seed> <threshold> <input_dir/crosses.chr3.int.fa.0.error> <output_dir/crosses.chr3.int.fa>
*/
/*
Correcting method:
Take the simulated raw nanoreads file, whose noise level at 0, meaning no filtering, or no data has dumped;
Then assign all bases (and their shadows) that are with Phredscore<= <threshold> to a new symbol '~', and '~' will be 
ignored in the following correcting procedure, thus all bases with Phredscores that did not pass will provide no
imformation for correction.
*/
/*
Following Correcting method:
Correct single flips:
>High Qscore, the single flip remains
>Low Qscore, the single flip corrected to the type of the one before it
Meanwhile correct all isolated double flips(using shadow1
as reference, thus implement the correction for single&double at the same time
on the raw error reads):
>High Qscore-product, the isodouble flip remains
>Low Qscore-product, the isodouble flip corrected to their surrounding
*/
#include "shared.h"

using namespace std;

int main(int argc, const char **argv) {

  makelog_corr (argc, argv);
  
  //Set up random number generator
  int seed=atoi(argv[1]);
  gsl_rng_env_setup();
  gsl_rng *rgen = gsl_rng_alloc (gsl_rng_taus);
  gsl_rng_set (rgen, seed);

  //read in samples and generate nanoreads:
  sequences samples;

  //Setting threshold:
  int threshold=atoi(argv[2]);
  //Clean up any old files
  string out_title=argv[4];
  string shadowfile=out_title+".shadow";
  string shadowfile1=out_title+".shadow1";
  remove(out_title.c_str());
  remove(shadowfile.c_str());
  remove(shadowfile1.c_str());

  //And create new files:
  string in_title=argv[3];
  string Qfile=in_title+".Q";
  ifstream infile(in_title);
  ifstream infileQ(Qfile);
  ofstream outfile_s1(shadowfile1,ios::app);//shadow of raw reads, added '~'
  ofstream outfile(out_title,ios::app);//Reads with corrected errors
  ofstream outfile_s(shadowfile,ios::app);//Shadow of reads with uncorrected errors
  //string checkfile=out_title+"check";/////////////////////////////////////////////////////////
  //ofstream check(checkfile,ios::app);//////////////////////////////////////////////////////////

  int count=0;
  string line;
  string lineQ;
  while(getline(infile,line)){
    getline(infileQ,lineQ);
    if(*(line.begin())=='>'){
      outfile_s1<<line<<'\n';
      outfile_s<<line<<'\n';
      outfile<<line<<'\n';
      //check<<lineQ<<'\n';///////////////////////////////////////////////////////////////////////
    }
    else{
     count++;
     if (count==1){
      outfile_s1<<line<<'\n';
      outfile_s<<line<<'\n';
      outfile<<line<<'\n';
      //check<<lineQ<<'\n';//////////////////////////////////////////////////////////////////////  
     }
     else{

      //Put this read(line) into <sequences>:samples.nread
      stringstream line_ss;
      line_ss<<line;
      char b;
      while(line_ss>>b){
        samples.nread.push_back(b);
      }


      //Read in this read(line)'s Phred numbers(int) 
      stringstream lineQ_ss;
      lineQ_ss<<lineQ;
      int d;
      while(lineQ_ss>>d){
        samples.Qnumber.push_back(d);
      }

      //Generate shadow1 for this read(line)'s uncorrected nread
      vector<char> shadow1;
      Shadow(samples.nread,shadow1);

      //Purging no-pass bases: chamge them to '~':
      for(int i=0; i<samples.nread.size();++i){
        if(samples.Qnumber[i]<threshold){
          samples.nread[i]='~';
          shadow1[i]='~';
        }
      }
      //And since all the no-pass provide no info, everything following them shouldn't be a flip:
      for(int i=0;i<shadow1.size();++i){
        if(shadow1[i]=='F'){
          if(shadow1[i-1]=='~'){
            shadow1[i]='-';
          }
        }
      }
      //output to shadow1 file
      for(int i=0;i<shadow1.size();++i){
        outfile_s1<<shadow1[i];
      }
      outfile_s1<<'\n';


      //Correcting single flips in nread according to its sahdow1
      for(int i=0;i<shadow1.size();++i){
            if(shadow1[i]=='F'){
              if(shadow1[i+1]=='F'){//For all F that is followed by an F: 
                                    //meaning: for isolated (--FF--) and consecutive (*F...F*) single flips
                double p=gsl_rng_uniform(rgen)*1;
                //If p>pow(10,(-samples.Qnumber[i]/10)), i.e., should smaples.nread[i] be "right": 
                //then do nothing, i.e., samples.nread[i]=samples.nread[i];
                if(p<=pow(10,(-samples.Qnumber[i]/10))){//If smaples.nread[i] should be "wrong":
                  samples.nread[i]='N';//turn all F that is followed by an F to 'N': 
                                       //for isolated (-FF-) and consecutive (*F...F*) single flips
                  if(shadow1[i-1]=='-'&&shadow1[i+2]!='F'){//in the case of isolated single flips
                    if(samples.nread[i-1]==samples.nread[i+1]){//If either side of the flip are of the same type,
                      samples.nread[i]=samples.nread[i-1];//then flip it back to its surrounding
                    }
                    else{//like "00N11", "NN100",...
                    samples.nread[i]='N';//the flip remains.
                    }  
                  } 
                }
              }
            }
          }
      //Correcting isolated double flips in nread according to its shadow1
      for(int i=2;i<shadow1.size()-4;++i){
        if((shadow1[i]=='F')&&(shadow1[i+1]=='-')&&(shadow1[i+2]=='F')){//All double flips
          if((shadow1[i-1]=='-')&&(shadow1[i-2]=='-')&&(shadow1[i+3]=='-')&&(shadow1[i+4]!='F')){//in the case of isolated double flips,
            double p=gsl_rng_uniform(rgen)*1;
            double q1=pow(10,(-samples.Qnumber[i]/10));
            double q2=pow(10,(-samples.Qnumber[i+1]/10));
            double q=q1*q2;
            //If p>q, i.e., should this double flip be "right": 
            //then do nothing, i.e., samples.nread[i]=samples.nread[i]=samples.nread[i+1];
            if(p<=q){//should this double flip be "wrong"
              if(samples.nread[i-1]==samples.nread[i+2]){//If either side of the double flip are of the same type,
                samples.nread[i]=samples.nread[i-1];
                samples.nread[i+1]=samples.nread[i-1];//they should be corrected to their surrounding
              }
              else{//when it is like "000NN111", "NNN11000"
                  samples.nread[i]='N';
                  samples.nread[i+1]='N';
              }
            }
          }
        }
      }

      
      //Change all the '~' to 'N':
      for(int i=0;i<samples.nread.size();++i){
        if(samples.nread[i]=='~'){
          samples.nread[i]='N';
        }
      }


      //Output to .int.fa file
      for(int i=0;i<samples.nread.size();++i){
        outfile<<samples.nread[i];
      }
      outfile<<'\n';


      //Generate shadow for this read(line)'s corrected nread
      vector<char> shadow;
      Shadow(samples.nread,shadow);
      //Output to shadow file
      for(int i=0;i<shadow.size();++i){
        outfile_s<<shadow[i];
      }
      outfile_s<<'\n';



      //Clean-up
      samples.parentinfo.clear();
      samples.Qnumber.clear();
      samples.nread.clear();
      }
    }
  }
  return 0;
}


