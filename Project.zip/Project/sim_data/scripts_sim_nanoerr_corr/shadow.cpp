#include <vector>
using namespace std;
		
	void Shadow(vector<char>& seq, vector<char>& shadow){
		shadow.push_back('-');
		for(int i=1;i<seq.size();i++){
			if(seq[i]==seq[i-1]){
				shadow.push_back('-');
			}
			else{
				shadow.push_back('F');
			}
		}
	}