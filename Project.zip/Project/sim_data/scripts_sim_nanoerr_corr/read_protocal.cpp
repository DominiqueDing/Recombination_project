//input Protocal-Kim
#include  "shared.h"

void ReadProtocal ( withPr& Protocal){

string line;

ifstream in_file("Protocal_Kim.txt");
int count=0;

while(getline(in_file,line)){
  ++count;
  if (count==1){
    stringstream line_ss;
    line_ss<<line;
    char a;
    while(line_ss>>a){
      Protocal.Phred.push_back(a);
    }
  }
  if (count==2){
    stringstream line_ss;
    line_ss<<line;
    char a;
    while(line_ss>>a){
      Protocal.Phred_number.push_back(a);
    }
  }
  if (count==4){
    stringstream line_ss;
    line_ss<<line;
    long double pr;
    while(line_ss>>pr){
      Protocal.PhredPr.push_back(pr);
    }
  }
  if (count==5){
    stringstream line_ss;
    line_ss<<line;
    int len;
    while(line_ss>>len){
      Protocal.length.push_back(len*0.001);
    }
  }
  if (count==7){
    stringstream line_ss;
    line_ss<<line;
    long double pr;
    while(line_ss>>pr){
      Protocal.lenPr.push_back(pr);
    }
  }
}
}



