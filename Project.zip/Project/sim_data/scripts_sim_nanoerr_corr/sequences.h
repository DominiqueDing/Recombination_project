#ifndef SEQUENCES_H
#define SEQUENCES_H

#include <vector>
using namespace std;

	struct sequences {
		vector <double> actposi;
        vector <int> segposi;
        vector <char> parentinfo;
        vector <double> range;
        vector <char> Qscores;
        vector <int> Qnumber;
        vector <char> nread; 
    };
#endif //SEQUENCES_H