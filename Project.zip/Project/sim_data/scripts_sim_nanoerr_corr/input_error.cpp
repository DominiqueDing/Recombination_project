/*
Generate crosses.chr3.int.fa.<threshold>.error file, i.e. raw simulated nanoreads
> in scripts/
$make 
$./input_error <seed> <threshold> <../raw_sim_nanoread/crosses.chr3.int.fa.<threshold>.error; i.e. output_seq_file> <input_seq_file>
*/
#include "shared.h"

using namespace std;

int main(int argc, const char **argv) {

  makelog_input_error (argc, argv);

  //Set up random number generator
  int seed=atoi(argv[1]);
  gsl_rng_env_setup();
  gsl_rng *rgen = gsl_rng_alloc (gsl_rng_taus);
  gsl_rng_set (rgen, seed);

  //set up the threshold for errors (in Q_number forms):
  int threshold=atoi(argv[2]);

  //generate sequence protocal:
  withPr Protocal;
  ReadProtocal(Protocal);

  //read in samples and generate nanoreads:
  sequences samples;

  //Clean up any old files
  string errorfile=argv[3];
  string Qfile=errorfile+".Q";
  string shadowfile=errorfile+".shadow";
  remove(errorfile.c_str());
  remove(Qfile.c_str());
  remove(shadowfile.c_str());

  //And create new files:
  ifstream infile(argv[4]);
  ofstream outfile_e(errorfile,ios::app);//Reads with uncorrected errors
  ofstream outfile_q(Qfile,ios::app);//Phread scroes of reads
  ofstream outfile_s(shadowfile,ios::app);//Shadow of reads with uncorrected errors

  int count=0;
  string line;
  while(getline(infile,line)){
    if(*(line.begin())=='>'){
      outfile_e<<line<<'\n';
      outfile_q<<line<<'\n';
      outfile_s<<line<<'\n';
    }
    else if(*(line.begin())=='#'){
      outfile_e<<line<<'\n';
      outfile_q<<line<<'\n';
      outfile_s<<line<<'\n';
    }
    else{
     count++;
     if (count==1){
      outfile_e<<line<<'\n';
      outfile_q<<line<<'\n';
      outfile_s<<line<<'\n';
     }
     else{

      //Put this read(line) into <sequences>:samples
      stringstream line_ss;
      line_ss<<line;
      char b;
      while(line_ss>>b){
        samples.parentinfo.push_back(b);
      }


      //Give this read(line) Phred numbers(int) 
      for(int point=0;point<samples.parentinfo.size();point++){
        long double sc;//to compare with cumulative pr.
        do{sc=gsl_rng_uniform(rgen)*1;}
        while(sc<Protocal.PhredPr[threshold]);
        for (int n = threshold; n < Protocal.PhredPr.size(); ++n){
          if(sc>=Protocal.PhredPr[n]){
            if(sc<=Protocal.PhredPr[n+1]){
              samples.Qnumber.push_back(n);//generate Qnumber for each base;
            }
          }
        }
      }
      //output to int.fa.Q doc:
      for(int point=0; point<samples.Qnumber.size();point++){
        outfile_q<<samples.Qnumber[point]<<' ';
      }
      outfile_q<<'\n';


      //Generate nanoread for this read(line)
      for(int point=0;point<samples.parentinfo.size();point++){
        double q=samples.Qnumber[point];
        double p;//to compare with P=10^(-q/10);
        p=gsl_rng_uniform(rgen)*1;
        if(p<=pow(10,(-q/10))){   //If base should be "wrong", randomly assign to {A,T,C,G}
          float base_ran=gsl_rng_uniform(rgen)*1;
          if(base_ran<0.25){        
            samples.nread.push_back('0');
          }  
          else if(base_ran<0.5){  
            samples.nread.push_back('1');
          }  
          else{  
            samples.nread.push_back('N');
          }  
        }
        else{
          samples.nread.push_back(samples.parentinfo[point]);
        }
      }
      //output to int.fa.error doc:
      for (int i=0;i<samples.nread.size();++i){
        outfile_e<<samples.nread[i];
      }
      outfile_e<<'\n';
      

      //Generate shadow for this read(line)'s uncorrected nread
      vector<char> shadow;
      Shadow(samples.nread,shadow);
      //Output to shadow file
      for(int i=0;i<shadow.size();++i){
        outfile_s<<shadow[i];
      }
      outfile_s<<'\n';

      //Clean-up
      samples.parentinfo.clear();
      samples.Qnumber.clear();
      samples.nread.clear();
      }
    }
  }
  return 0;
}


