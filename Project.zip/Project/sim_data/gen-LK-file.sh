#!/bin/bash

#Generate customised (for the remaining sequence_count) LK file for the analysis

seq_count=`head -1 simulation_data_match_N100/input_profile_mean_chr3_2way.txt.N1.0e5.6330.sample.1.Ns100.12gen | awk '{ print $1 }'`
sed "s/10000/${seq_count}/" <../LKsurfaces/lkInfiniteNwayNg10000_realtime_g10001 >../LKsurfaces/lkInfiniteNwayNg${seq_count}_realtime_g10001