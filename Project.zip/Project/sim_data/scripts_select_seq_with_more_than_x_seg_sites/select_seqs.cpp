/*
Tease out sequence reads with less than "seg_n" seqgregation sites reads from a seq_file
./select_seqs <seg_n> <original_seq_file> <out_put_seq_file>
*/

#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
#include <vector>
#include <string>
#include <algorithm>
#include <map>
#include <sstream>
#include <fstream>
#include <stdio.h>
#include <math.h>

using namespace std;

int main(int argc, char **argv){
	int seg_n=atoi(argv[1]);
	ifstream in_seq(argv[2]);
	string out_seq_title=argv[3];
	string out_seq_tmp_title=out_seq_title+".tmp";
	remove(out_seq_title.c_str());
	remove(out_seq_tmp_title.c_str());
	ofstream out_seq_tmp(out_seq_tmp_title, ios::app);
	ofstream out_seq(out_seq_title,ios::app);
	
	vector<int> header;
	int seq_num=0;
	string line;
	int ct=0;
	while(getline(in_seq,line)){
		if(line.front()!='>'){
			ct++;
			if(ct==1){
				//cout<<line<<'\n';//////////////////////////////////////////
				stringstream line_ss;
				line_ss<<line;
				int head;
				while(line_ss>>head){
					header.push_back(head);
				}
			}
			else{
				//cout<<line<<'\n';/////////////////////////////////////////////
				int ct0=count(line.begin(),line.end(),'0');
				int ct1=count(line.begin(),line.end(),'1');
				//cout<<ct0<<' '<<ct1<<'\n';//////////////////////////////////////////////
				if(ct0+ct1>seg_n-1){
					seq_num++;
					out_seq_tmp<<">seq_"<<ct-1<<'\n';
					out_seq_tmp<<line<<'\n';
				}
			}
		}
	}
	//cout<<header[0]<<' '<<header[1]<<' '<<header[2]<<'\n';///////////////////////////////////////////////////
	header[0]=seq_num;
	char buffer [50];
	sprintf(buffer, "%d %d %d", header[0],header[1],header[2]);
	out_seq<<buffer<<'\n';
	ifstream in_tmp(out_seq_tmp_title);
	string line_tmp;
	while(getline(in_tmp,line_tmp)){
		out_seq<<line_tmp<<'\n';
	}
	remove(out_seq_tmp_title.c_str());
  return 0;
}
