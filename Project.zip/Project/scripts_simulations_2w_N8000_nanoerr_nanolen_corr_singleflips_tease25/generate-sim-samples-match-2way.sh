#!/bin/bash


outdir="../sim_data/simulation_data_match_N172"
#inputProfileList="../input_profiles/input_profile_mean*2way.txt"

inputProfileList="../sim_input_profiles/input_profile_mean_chr3_2way.txt"
mkdir -p $outdir

# how many replicates to be performed
head -2 "seed.vector.500.txt"  > seed.tmp.txt
seedFile="seed.tmp.txt"

N="1.0e5";


for inputProfile in $inputProfileList
do
    i=1;
    cat $seedFile | while read seed
    do
	
	list=($(echo $inputProfile | tr "/" "\n"));
	tag=${list[2]};

				
		echo $seed $N $tag
		
		awk '{print $0}' $inputProfile > tmp.profile
		
		#	./../codes/crossing/run_crossing_hs_match $N 2 172 $seed $outdir tmp.profile  > $outdir/$tag.N$N.$seed.sample.$i.Ns172.2gen		
			./../codes/crossing/run_crossing_hs_match $N 12 172 $seed $outdir tmp.profile  > $outdir/$tag.N$N.$seed.sample.$i.Ns172.12gen		
		
	   
	let i++
    done
    
done



