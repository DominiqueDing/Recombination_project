#!/bin/bash

set -e
#test if customisation has already performed
if test -e customise.log; then
	echo "It has already been run, check the files!"
	exit 1
fi

#if not create logfile to mark it
echo "----------------------------------------------------------------" >>customise.log
echo "----------------------------------------------------------------" >>customise.log
date>>customise.log
echo "Running customise.sh" >> customise.log
#customise
PRECUSTOM=`pwd | awk -F '/' '{print $NF}'`
CUSTOM=`echo ${PRECUSTOM} | sed 's/scripts_simulations_2w_//'`

sed -i  -e "s/simulation_data_match/simulation_data_match_${CUSTOM}/" -e "s/inference_results_sim_example/inference_results_sim_example_${CUSTOM}/" example-inference-sim-2way.0.sh

sed -i  -e "s/simulation_data_match/simulation_data_match_${CUSTOM}/" -e "s/inference_results_sim_example/inference_results_sim_example_${CUSTOM}/" example-inference-sim-2way.0.0.sh

sed -i -e "s/scripts_simulations_2w/${PRECUSTOM}/" slurm_submit.0.darwin

sed -i -e "s/scripts_simulations_2w/${PRECUSTOM}/" slurm_submit.0.0.darwin
