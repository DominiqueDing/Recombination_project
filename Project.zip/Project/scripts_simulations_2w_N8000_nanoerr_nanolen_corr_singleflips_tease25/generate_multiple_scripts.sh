#!/bin/bash
declare -i index_id

for index_id in {1..100}
do
cp example-inference-sim-2way.0.sh example-inference-sim-2way.${index_id}.sh
done
